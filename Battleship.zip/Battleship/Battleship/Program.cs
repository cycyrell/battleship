﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Battleship {
    class Program
    {   
    //board is where ships are located
    static String[] player2Board = new String[100];
    static String[] player1Board = new string[100];

    //hit is the one where you start playing
    static String[] player2hit = new string[100];
    static String[] player1hit = new string[100];

    static int hitCounterPlayer1 = 0;
    static int hitCounterPlayer2 = 0;

    static Boolean winnerPlayer = false;

    static void initializeVariables()

    {
        for (int i = 0; i < 100; i++)
        {
            player1Board[i] = " ";
            player2Board[i] = " ";
            player1hit[i] = " ";
            player2hit[i] = " ";
        }
    }

    static void Main(string[] args)
    {
        initializeVariables();
        introduction();
        askData();
        scoreboard();

    }

    static void scoreboard()
    {
        Console.Clear();
        Console.WriteLine("Thank you for playing Battleship!");
        Console.WriteLine("The winner is: ");
        if (hitCounterPlayer1 == 26)
            Console.WriteLine("Player 1!");
        else
            Console.WriteLine("Player 2!");
        Console.WriteLine("\nThank you for playing.");
        Console.ReadLine();

    }

    static void inputShipLocation()
    {
        //N
        //W S
        //S

        Console.Clear();
        Console.WriteLine("This is the turn for Player 1! Player 2: LEAVE!");
        Console.ReadLine();
        Console.Clear();
        //if (selection.equals("N"))
        //  p1Board[i] && p1Board[i +- 10]
        Console.WriteLine("Please select the location of your ship (patrol) based on the box #");
        drawBoard("P1");
        int selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        //0 | 1 | 2 | 3
        //  S| S | S | S |-
        player1Board[selection] = "S";
        player1Board[selection + 1] = "S";

        //---------
        Console.WriteLine("Please select the location of your ship (Destroyer) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player1Board[selection] = "S";
        player1Board[selection + 1] = "S";
        player1Board[selection + 2] = "S";

        //---------
        Console.WriteLine("Please select the location of your ship (Submarine) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player1Board[selection] = "S";
        player1Board[selection + 1] = "S";
        player1Board[selection + 2] = "S";

        //---------
        Console.WriteLine("Please select the location of your ship (Destroyer) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player1Board[selection] = "S";
        player1Board[selection + 1] = "S";
        player1Board[selection + 2] = "S";
        player1Board[selection + 3] = "S";

        //---------
        Console.WriteLine("Please select the location of your ship (battleship) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player1Board[selection] = "B";
        player1Board[selection + 1] = "B";
        player1Board[selection + 2] = "B";
        player1Board[selection + 3] = "B";

        //---------
        Console.WriteLine("Please select the location of your ship (Carrier) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player1Board[selection] = "S";
        player1Board[selection + 1] = "S";
        player1Board[selection + 2] = "S";
        player1Board[selection + 3] = "S";
        player1Board[selection + 4] = "S";

        //----------------------------

        Console.Clear();
        Console.WriteLine("Player 2! Your turn right now! Press any key to continue.");
        Console.ReadLine();

        Console.WriteLine("Please select the location of your ship (patrol) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player2Board[selection] = "S";
        player2Board[selection + 1] = "S";

        //---------
        Console.WriteLine("Please select the location of your ship (Destroyer) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player2Board[selection] = "S";
        player2Board[selection + 1] = "S";
        player2Board[selection + 2] = "S";

        //---------
        Console.WriteLine("Please select the location of your ship (Submarine) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player1Board[selection] = "S";
        player1Board[selection + 1] = "S";
        player1Board[selection + 2] = "S";

        //---------
        Console.WriteLine("Please select the location of your ship (Destroyer) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player1Board[selection] = "S";
        player1Board[selection + 1] = "S";
        player1Board[selection + 2] = "S";
        player1Board[selection + 3] = "S";

        //---------
        Console.WriteLine("Please select the location of your ship (battleship) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player1Board[selection] = "B";
        player1Board[selection + 1] = "B";
        player1Board[selection + 2] = "B";
        player1Board[selection + 3] = "B";

        //---------
        Console.WriteLine("Please select the location of your ship (Carrier) based on the box #");
        drawBoard("P1");
        selection = Convert.ToInt32(Console.ReadLine());
        //09 -> 10
        //19 -> 20 ERROR!
        //29 -> 30 ERROR!

        player1Board[selection] = "S";
        player1Board[selection + 1] = "S";
        player1Board[selection + 2] = "S";
        player1Board[selection + 3] = "S";
        player1Board[selection + 4] = "S";
        //----------------------------
    }


    static void promptHit()
    {
        Console.Clear();
        Console.WriteLine("Player 1: Please enter your selection based on the previous hit field.");
        drawBoard("P1Hit");
        int selection = Convert.ToInt32(Console.ReadLine());
        if (player1Board[selection] != " ")
        {
            Console.WriteLine("HIT!");
            player1hit[selection] = "H";
            hitCounterPlayer1++;
            if (hitCounterPlayer1 == 21)
                winnerPlayer = true;
        }
        else
        {
            Console.WriteLine("MISS!");
            player1hit[selection] = "M";
        }
        Console.WriteLine("\nPress any key to continue.");
        Console.ReadLine();
        Console.Clear();
        Console.WriteLine("Player 12 Please enter your selection based on the previous hit field.");
        drawBoard("P2Hit");
        selection = Convert.ToInt32(Console.ReadLine());
        if (player1Board[selection] != " ")
        {
            Console.WriteLine("HIT!");
            player2hit[selection] = "H";
            hitCounterPlayer2++;
            if (hitCounterPlayer2 == 21)
                winnerPlayer = true;

        }
        else
        {
            Console.WriteLine("MISS!");
            player2hit[selection] = "M";
        }
        Console.WriteLine("\nPress any key to continue.");
        Console.ReadLine();
    }

    static void askData()
    {
        inputShipLocation();
        while (winnerPlayer)
        {
            promptHit();

        }

    }

    static void drawBoard(String selection)
    {
        if (selection.Equals("P1"))
        {
            for (int x = 0; x < 10; x++)
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.Write(player1Board[i + x] + "|");
                }
                Console.WriteLine();
            }
        }
        else if (selection.Equals("P2"))
        {
            for (int x = 0; x < 10; x++)
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.Write(player2Board[i + x] + "|");
                }
                Console.WriteLine();
            }
        }
        else if (selection.Equals("P1Hit"))
        {
            for (int x = 0; x < 10; x++)
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.Write(player1hit[i + x] + "|");
                }
                Console.WriteLine();
            }
        }
        else
        {

            for (int x = 0; x < 10; x++)
            {
                for (int i = 0; i < 10; i++)
                {
                    Console.Write(player2hit[i + x] + "|");
                }
                Console.WriteLine();
            }

        }
    }
    static void introduction()
    {
        Console.Title = "Battleship";

        Console.WriteLine("Welcome to Battleship.\n\nPress any key to continue.");
        Console.ReadLine();
    }
}
    }